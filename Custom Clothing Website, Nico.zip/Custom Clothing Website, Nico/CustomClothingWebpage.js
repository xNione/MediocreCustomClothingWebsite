function createGiftCardd(){
				var man = document.getElementById("radMan");
				var woman = document.getElementById("radWoman");
				var card = document.getElementById("card");
				var other = document.getElementById("radOther");
				var imgPaths;

				var name = document.getElementById("txtName").value;
				var namePara = document.getElementById("namePara");

				if(man.checked==true){
					imgPath = man.value;
					card.style.backgroundImage = 'url('+ 'img/whiteshirt.jpg' +') ';
					card.style.backgroundSize = 'contain';
					card.style.color = 'white';
					card.style.fontSize = '30px';
				} 
				else if(woman.checked==true) {
					imgPath = woman.value;
					card.style.backgroundImage = 'url('+ 'img/womendress.jpg' +') ';
					card.style.backgroundSize = 'cover';
					card.style.color = 'white';
					card.style.fontSize = '30px';

				}
				else {
					imgPath = other.value;
					card.style.backgroundImage = 'url('+ 'img/other.png' +') ';
					card.style.backgroundSize = 'cover';
					card.style.color = 'black';
					card.style.fontSize = '30px';

				}

				namePara.innerHTML = name;
			}
			
			//$(document).ready(function(){
				//$('.carousel').carousel();
			//});
